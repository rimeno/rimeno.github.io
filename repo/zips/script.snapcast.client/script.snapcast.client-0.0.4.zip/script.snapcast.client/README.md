# script.snapcast.client

**Deprecated !!! Remove it and see [script.service.snapcast-client](https://github.com/rimeno/script.service.snapcast-client)**


Basic GUI client to start or stop a (systemd --user) snapcast.service. It depends on
[service.snapcast.client](https://rimeno.github.io/service.snapcast.client) to ensure
autostop if Kodi start playing.


## Features

* Start
* Stop

## Install the addon

### From repository

Add Rafaneto repository by installing this zip file [repository.rafaneto-0.0.2.zip](https://rimeno.github.io/repository.rafaneto-0.0.2.zip)
and then search "snapcast" in "program" category.

### Build

Install necessary dependencies for this addon.

* [script.module.snapcast](https://github.com/rimeno/script.module.snapcast),
* [service.snapcast.client](https://github.com/rimeno/service.snapcast.client),

To make the package (in your TMPDIR) :

```
git clone https://github.com/rimeno/script.snapcast.client
cd script.snapcast.client
./make.sh
```
