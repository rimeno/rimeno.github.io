#!/usr/bin/env python
# -*- coding: utf-8 -*-

# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: 2022 rimeno <rafaneto@punktona.org>

import xbmc
import subprocess
import xbmcaddon


class Systemctl():

    def __init__(self, service):
        self.service = service
        self.user = '--user'
        self.addon = xbmcaddon.Addon()

    def start(self):
        xbmc.log("{} : systemctl {} {} {}".format(
            self.addon.getAddonInfo('id'), "start", self.user, self.service
        ),
                 level=xbmc.LOGINFO)
        ret = subprocess.run(['systemctl', "start", self.user, self.service])
        if ret.returncode == 0:
            return True
        else:
            return False

    def stop(self):
        xbmc.log("{} : systemctl {} {} {}".format(
            self.addon.getAddonInfo('id'), "stop", self.user, self.service
        ),
                 level=xbmc.LOGINFO)
        ret = subprocess.run(['systemctl', "stop", self.user, self.service])
        if ret.returncode == 0:
            return True
        else:
            return False

    def isActive(self):
        ret = subprocess.run(['systemctl', self.user, "is-active",
                              self.service])
        if ret.returncode != 0:
            return False
        else:
            return True

# VIM MODLINE
# vim: set ai shiftwidth=4 tabstop=4 expandtab:
