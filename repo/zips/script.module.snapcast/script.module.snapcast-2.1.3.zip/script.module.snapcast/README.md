# script.module.snapcast

Library from [https://github.com/happyleavesaoc/python-snapcast](https://github.com/happyleavesaoc/python-snapcast)
packaged for Kodi.

## Install

### From repository

Download [https://rimeno.github.io/repository.rafaneto-0.0.1.zip](https://rimeno.github.io/repository.rafaneto-0.0.1.zip) and install it from zip.

### Build

To make the package (in your TMPDIR) :

```
git clone https://github.com/rimeno/script.module.snapcast
cd script.module.snapcast
./make.sh
```
