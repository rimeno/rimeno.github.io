#!/usr/bin/env python
# -*- coding: utf-8 -*-

# SPDX-License-Identifier: GPL-3.0-or-later
# SPDX-FileCopyrightText: 2017 frafall
# SPDX-FileCopyrightText: 2022 rimeno <rafaneto@punktona.org>

import xbmc
import xbmcaddon
import xbmcgui

from resources.lib.systemd import Systemctl
from resources.lib.snapcontrol import SnapControl

addon = xbmcaddon.Addon()

notifIcon = addon.getAddonInfo('path') + "/resources/icon.png"


class Monitor(xbmc.Monitor):

    def __init__(self, player):
        super(Monitor, self).__init__(self)
        self.player = player

    def onSettingsChanged(self):
        xbmc.log("{} : event onSettingsChanged!".format(
            addon.getAddonInfo('id')),
                 level=xbmc.LOGINFO)


class Player(xbmc.Player):

    def __init__(self):
        super(Player, self).__init__(self)
        self.service = Systemctl("snapclient")

    def start(self):
        if not self.service.isActive():
            self.service.start()
            control = SnapControl()
            if control.client and control.sync:
                control.syncVol("K2S")
            xbmcgui.Dialog().notification('Snapcast',
                                          addon.getLocalizedString(34011),
                                          notifIcon, 5000, False)

    def stop(self):
        if self.service.isActive():
            self.service.stop()
            xbmcgui.Dialog().notification('Snapcast',
                                          addon.getLocalizedString(34012),
                                          notifIcon, 5000, False)

    def onStartup(self):
        xbmc.log("{} : event onStartup!".format(
            addon.getAddonInfo('id')),
                 level=xbmc.LOGINFO)
        if addon.getSetting("StartupAutoStart") == "true":
            self.start()
        else:
            xbmc.log("{} : not started due to settings".format(
                addon.getAddonInfo('id')),
                     level=xbmc.LOGINFO)

    def onShutdown(self):
        xbmc.log("{} : event onShutdown!".format(
            addon.getAddonInfo('id')),
                 level=xbmc.LOGINFO)
        self.stop()

    def onPlayBackStarted(self):
        xbmc.log("{} : event onPlayBackStarted!".format(
            addon.getAddonInfo('id')),
                 level=xbmc.LOGINFO)
        self.stop()

    def onPlayBackStopped(self):
        xbmc.log("{} : event onPlayBackStopped! {}".format(
            addon.getAddonInfo('id'), addon.getSetting("AutoStart")),
                 level=xbmc.LOGINFO)
        if addon.getSetting("AutoStart") == "true":
            self.start()
        else:
            xbmc.log("{} : not started due to settings".format(
                addon.getAddonInfo('id')),
                     level=xbmc.LOGINFO)

    def onPlayBackPaused():
        xbmc.log("{} : event onPlayBackPaused!".format(
            addon.getAddonInfo('id')),
                 level=xbmc.LOGINFO)

    def onPlayBackResumed():
        xbmc.log("{} : event onPlayBackResumed!".format(
            addon.getAddonInfo('id')),
                 level=xbmc.LOGINFO)


if __name__ == '__main__':
    xbmc.log("{} : Initializing snapcast addon!".format(
        addon.getAddonInfo('id')),
             level=xbmc.LOGINFO)
    player = Player()
    Monitor(player).waitForAbort()


# VIM MODLINE
# vim: set ai shiftwidth=4 tabstop=4 expandtab:
