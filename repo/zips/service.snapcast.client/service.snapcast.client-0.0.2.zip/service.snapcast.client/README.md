# service.snapcast.client

Basic service that stop Snapcast client when kodi is playing.

Thanks to [frafall](https://github.com/frafall/service.snapcast) for is original work for LibreELEC.

## Features

* Optionally autostart snapcast on Kodi startup
* Optionally autostart snapcast when Kodi stop playing
* Optionally sync volume from Kodi to snapcast

* No dependencies on LibreELEC
* Dependency on systemd
* Python 3

## Install the addon

### From repository

Add Rafaneto repository by installing this zip file [repository.rafaneto-0.0.2.zip](https://rimeno.github.io/repository.rafaneto-0.0.2.zip)
and then search "snapcast" in "service" category.

### Build

Install [script.module.snapcast](https://github.com/rimeno/script.module.snapcast),
a necessary dependency of this addon.

To make the package (in your TMPDIR) :

```
git clone https://github.com/rimeno/service.snapcast.client
cd service.snapcast.client
./make.sh
```

## Notes

This addon will not install Snapcast server nor Snapcast client.
You have to setup your snapclient installation with systemd in userspace and it should
run with the Kodi user.

For instance, if the home directory of your Kodi user is `/home/kodi` and you have configured
snapclient in `/home/kodi/.config/snapclient`, you could use this service for your 
`/home/kodi/.config/systemd/user/snapclient.service`

```INI
[Unit]
Description=Snapcast client
Documentation=man:snapclient(1)
Wants=avahi-daemon.service
After=network.target time-sync.target sound.target avahi-daemon.service pulseaudio.service

[Service]
EnvironmentFile=-/home/kodi/.config/snapclient
ExecStart=/usr/bin/snapclient $SNAPCLIENT_OPTS
# very noisy on stdout
StandardOutput=null
Restart=on-failure

[Install]
WantedBy=default.target
```
